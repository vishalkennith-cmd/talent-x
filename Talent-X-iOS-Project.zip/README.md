# Talent-X for iOS

A native iOS shell for the Talent-X marketplace prototype. It packages the existing recruiter, company, and administrator workspaces in a `WKWebView` and keeps demo workspace edits on the device.

## Open and run

1. Open `TalentX.xcodeproj` in Xcode on a Mac.
2. Select the shared `Talent-X` scheme and an iPhone or iPad simulator.
3. Press Run. For a physical device or distribution archive, select your Apple developer signing team in Xcode.

The project targets iOS 15 and later. The web experience is bundled with the app and works offline. Its demo sign-in accepts any valid email and a password of at least six characters, or use the one-tap demo sign-in. Authentication is a prototype only; there is no server account system.

## Included flows

- Recruiter: browse roles, submit candidates with consent, track applications, and review earnings.
- Company: post roles, review candidate pipelines, schedule interviews, and view payments.
- Administrator: review marketplace activity, candidate ownership, recruiter trust, and payments.

Changes made in the demo workspace are stored locally on the device. No custom App Store icon, Apple signing identity, or compiled `.app`/`.ipa` is included in this source package.
