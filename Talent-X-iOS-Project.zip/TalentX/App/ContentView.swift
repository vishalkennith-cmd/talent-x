import SwiftUI
import WebKit

struct ContentView: View {
    var body: some View {
        TalentXWebView()
            .background(Color(red: 0.965, green: 0.969, blue: 0.957))
            .ignoresSafeArea(.container, edges: .bottom)
    }
}

private struct TalentXWebView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true

        let contentController = WKUserContentController()
        contentController.add(context.coordinator, name: Coordinator.storageMessageName)
        contentController.addUserScript(context.coordinator.makeStorageScript())
        configuration.userContentController = contentController

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 0.965, green: 0.969, blue: 0.957, alpha: 1)
        webView.scrollView.backgroundColor = webView.backgroundColor
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.allowsBackForwardNavigationGestures = false

        if let startPage = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Web") {
            webView.loadFileURL(startPage, allowingReadAccessTo: startPage.deletingLastPathComponent())
        }
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {}

    @MainActor
    final class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler {
        static let storageMessageName = "talentXStorage"
        private let storageKey = "com.talentx.ios.localStorage.v1"

        func makeStorageScript() -> WKUserScript {
            let saved = UserDefaults.standard.dictionary(forKey: storageKey) as? [String: String] ?? [:]
            let encoded = (try? JSONSerialization.data(withJSONObject: saved, options: [.fragmentsAllowed, .sortedKeys])) ?? Data("{}".utf8)
            let initialState = String(data: encoded, encoding: .utf8) ?? "{}"
            let source = """
            (() => {
              const initial = \(initialState);
              const state = new Map(Object.entries(initial).map(([key, value]) => [key, String(value)]));
              const flush = () => window.webkit.messageHandlers.talentXStorage.postMessage(Object.fromEntries(state.entries()));
              const storage = Object.freeze({
                get length() { return state.size; },
                key(index) { return Array.from(state.keys())[index] ?? null; },
                getItem(key) { key = String(key); return state.has(key) ? state.get(key) : null; },
                setItem(key, value) { state.set(String(key), String(value)); flush(); },
                removeItem(key) { state.delete(String(key)); flush(); },
                clear() { state.clear(); flush(); }
              });
              try { Object.defineProperty(window, 'localStorage', { configurable: true, value: storage }); } catch (_) {}
            })();
            """
            return WKUserScript(source: source, injectionTime: .atDocumentStart, forMainFrameOnly: true)
        }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.name == Self.storageMessageName,
                  let values = message.body as? [String: String] else { return }
            UserDefaults.standard.set(values, forKey: storageKey)
        }

        func webView(_ webView: WKWebView,
                     decidePolicyFor navigationAction: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            decisionHandler(navigationAction.request.url?.isFileURL == true ? .allow : .cancel)
        }
    }
}
